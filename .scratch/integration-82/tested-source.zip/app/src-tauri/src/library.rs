//! 拆书库扫描：识别「根目录散文件」与「一书一文件夹」两种既有布局（ADR 0002）。
//! 只读不写，不搬动、不改写用户文件。

use std::fs;
use std::path::{Path, PathBuf};

use serde::{Deserialize, Serialize};

use crate::book_file::{
    has_md_extension, is_hidden, meta_from_mapping, read_text, read_yaml_mapping,
    sanitize_file_name, sibling_yaml_path, write_text_atomic, BookMeta,
};
use crate::inspiration::LIBRARY_DIR;
use crate::proofread::PROOFREAD_DIR;
use crate::trope::{tropes_from_mapping, TropeSpan};

/// 构思项目在库根下的目录名；书库扫描、全文搜索、词表聚合（共用本模块的
/// 书文件收集）跳过该目录——拆书与构思只经「词表.yaml ＋ 灵感库」通行，
/// 见 docs/spec/构思数据模型.md。
pub const PROJECTS_DIR: &str = "项目";

/// 拆书模板（工单 #29，spec 拆书保存与模板 §三）：库根一份、用户自编辑，
/// 只作用于新建书。首次使用（点「拆书模板」入口或新建书）不存在则落
/// 默认模板——书档头卡＋空行＋第1章；占位符仅 `{书名}` 一个。
pub const TEMPLATE_FILE: &str = "拆书模板.md";
pub const DEFAULT_TEMPLATE: &str =
    "> [!书档]\n> 书名：{书名}\n> 成绩：\n> 简介：\n> 金手指：\n\n第1章\n";

fn template_path(root: &Path) -> PathBuf {
    root.join(TEMPLATE_FILE)
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "kebab-case")]
pub enum Layout {
    /// 根目录散文件：书的 .md 直接放在库根目录。
    Scattered,
    /// 一书一文件夹：每本书独占一个子文件夹（拆书.md + .yaml + 附件/）。
    FolderBook,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct BookEntry {
    pub name: String,
    pub layout: Layout,
    pub primary_md: PathBuf,
    pub md_count: u32,
    pub chapter_count: u32,
    pub word_count: u64,
    /// 同名 .yaml 的书级四项＋章前缀；无 yaml 或损坏时为缺省（编辑器打开会告警）。
    pub meta: BookMeta,
    /// 同名 .yaml 的桥段标注列表；无 yaml 或损坏时为空。
    pub tropes: Vec<TropeSpan>,
    /// 封面文件（约定文件名 附件/封面.png|jpg|webp，现查现识别，零 yaml 键）；
    /// 无封面为 None，前端以书名首字占位。删文件即撤。
    pub cover: Option<PathBuf>,
    /// 封面目录（「设封面」的拷贝落点）：一书一文件夹＝书内 附件/，
    /// 散文件书＝库根 附件/<书名>/（与截图粘贴同路径纪律）。
    pub cover_dir: PathBuf,
}

struct MdStats {
    chapters: u32,
    words: u64,
}

/// 一本书在盘上的全部 .md 与主文件（书库扫描与全文搜索共用同一套布局识别）。
pub(crate) struct BookFiles {
    pub(crate) name: String,
    pub(crate) layout: Layout,
    pub(crate) mds: Vec<PathBuf>,
    pub(crate) primary_md: PathBuf,
}

pub fn scan_library(root: &Path) -> Result<Vec<BookEntry>, String> {
    let root = root.to_path_buf();
    Ok(collect_book_files(&root)?
        .into_iter()
        .map(|files| book_entry(&root, files))
        .collect())
}

/// 封面目录（约定）：一书一文件夹＝书内 附件/；散文件书＝库根
/// 附件/<书名>/（与 book_file::attachment_subdir 同路径纪律）。
fn cover_dir_for(root: &Path, files: &BookFiles) -> PathBuf {
    match files.layout {
        Layout::FolderBook => files.primary_md.parent().unwrap_or(root).join("附件"),
        Layout::Scattered => root.join("附件").join(&files.name),
    }
}

/// 新建拆书书（工单 #20，spec 书库新建与展示 §二）：一律一书一文件夹——
/// 建「《书名》/」＋初始 拆书.md（v2：套用库根拆书模板，工单 #29）；
/// yaml 与 附件/ 懒生成（首次结构化标注/贴图才落盘，#13 纪律）。
/// 重名报错不续号：书是唯一的，同名是误操作（同 create_project）。
pub fn create_book(root: &Path, title: &str) -> Result<BookEntry, String> {
    if !root.is_dir() {
        return Err(format!("不是有效的文件夹：{}", root.display()));
    }
    let title = title
        .trim()
        .trim_start_matches('《')
        .trim_end_matches('》')
        .trim();
    let name = sanitize_file_name(title).map_err(|_| "书名不能为空（或只剩符号）".to_string())?;
    let dir = root.join(format!("《{name}》"));
    if dir.exists() {
        return Err(format!("已存在同名书「{name}」"));
    }
    fs::create_dir_all(&dir).map_err(|e| format!("无法创建文件夹 {}：{e}", dir.display()))?;
    let primary_md = dir.join("拆书.md");
    write_text_atomic(&primary_md, &initial_draft(root, &name))
        .map_err(|e| format!("无法创建拆书稿 {}：{e}", primary_md.display()))?;
    Ok(book_entry(
        root,
        BookFiles {
            name: format!("《{name}》"),
            layout: Layout::FolderBook,
            mds: vec![primary_md.clone()],
            primary_md,
        },
    ))
}

/// 新建书初始稿：库根拆书模板（不存在先落默认模板——懒生成在此触发），
/// `{书名}` 全文替换。模板读写任何失败都回退空稿、不阻断新建——模板是
/// 便利，不是闸（spec 拆书保存与模板 §三）。
fn initial_draft(root: &Path, name: &str) -> String {
    let path = template_path(root);
    if !path.is_file() {
        if let Err(e) = write_text_atomic(&path, DEFAULT_TEMPLATE) {
            eprintln!("默认拆书模板落盘失败（新建书回退空稿）：{e}");
            return String::new();
        }
    }
    match read_text(&path) {
        Ok(template) => template.replace("{书名}", name),
        Err(e) => {
            eprintln!("拆书模板读取失败（新建书回退空稿）：{e}");
            String::new()
        }
    }
}

/// 打开拆书模板（工单 #29，spec 拆书保存与模板 §三）：库根 `拆书模板.md`
/// 不存在则先落默认模板，再按散文件书形状包一个条目返回——前端以同一
/// 拆书编辑器编辑（同一套保存网），返回回书库。模板不是书：扫描排除。
pub fn open_book_template(root: &Path) -> Result<BookEntry, String> {
    if !root.is_dir() {
        return Err(format!("不是有效的文件夹：{}", root.display()));
    }
    let path = template_path(root);
    if !path.is_file() {
        write_text_atomic(&path, DEFAULT_TEMPLATE)
            .map_err(|e| format!("无法创建拆书模板 {}：{e}", path.display()))?;
    }
    let mut entry = book_entry(
        root,
        BookFiles {
            name: "拆书模板".to_string(),
            layout: Layout::Scattered,
            mds: vec![path.clone()],
            primary_md: path,
        },
    );
    // 模板里的书档键名行是 `{书名}` 占位符——模板不是书，条目名固定。
    entry.name = "拆书模板".to_string();
    Ok(entry)
}

pub(crate) fn collect_book_files(root: &Path) -> Result<Vec<BookFiles>, String> {
    let entries =
        fs::read_dir(root).map_err(|e| format!("无法读取文件夹 {}：{e}", root.display()))?;
    let mut books: Vec<BookFiles> = Vec::new();
    let mut subdirs: Vec<PathBuf> = Vec::new();

    for entry in entries.flatten() {
        let path = entry.path();
        if is_hidden(&path) {
            continue;
        }
        if path.is_dir() {
            subdirs.push(path);
        } else if has_md_extension(&path) {
            // 库根的拆书模板不是一本书（工单 #29）：扫描/全文搜索/词表聚合
            // 共用这里的收集，一处排除三处生效。
            if path.file_name().and_then(|n| n.to_str()) == Some(TEMPLATE_FILE) {
                continue;
            }
            books.push(BookFiles {
                name: file_stem_of(&path),
                layout: Layout::Scattered,
                mds: vec![path.clone()],
                primary_md: path,
            });
        }
    }
    for dir in subdirs {
        // 「灵感库/」是卡片目录、「项目/」是构思工程、「校对/」是词库，都不是一本书。
        if dir
            .file_name()
            .and_then(|n| n.to_str())
            .is_some_and(|n| n == LIBRARY_DIR || n == PROJECTS_DIR || n == PROOFREAD_DIR)
        {
            continue;
        }
        if let Some(files) = folder_book_files(&dir) {
            books.push(files);
        }
    }
    books.sort_by(|a, b| a.name.cmp(&b.name));
    Ok(books)
}

fn folder_book_files(dir: &Path) -> Option<BookFiles> {
    let mut mds: Vec<PathBuf> = Vec::new();
    let entries = fs::read_dir(dir).ok()?;
    for entry in entries.flatten() {
        let path = entry.path();
        if !is_hidden(&path) && path.is_file() && has_md_extension(&path) {
            mds.push(path);
        }
    }
    if mds.is_empty() {
        return None;
    }
    mds.sort();

    let primary = mds
        .iter()
        .find(|p| p.file_name().is_some_and(|n| n == "拆书.md"))
        .unwrap_or(&mds[0])
        .clone();

    Some(BookFiles {
        name: dir.file_name()?.to_string_lossy().into_owned(),
        layout: Layout::FolderBook,
        mds,
        primary_md: primary,
    })
}

fn book_entry(root: &Path, files: BookFiles) -> BookEntry {
    let (chapters, words) = files
        .mds
        .iter()
        .map(|md| md_stats(md))
        .fold((0u32, 0u64), |(c, w), s| (c + s.chapters, w + s.words));

    let (mut meta, tropes) = meta_and_tropes(&files.primary_md);
    // 书档四项上纸面（工单 #30，spec 拆书保存与模板 §四/§五）：列表取数
    // md 书档 > yaml 残键（未迁移旧书的过渡显示）> 空——扫描只读不写盘。
    // 主名口径＝书档书名 > yaml 书名 > 文件夹名（散文件书＝文件名）。
    if let Ok(text) = read_text(&files.primary_md) {
        if let Some(header) = crate::book_file::parse_book_header(&text) {
            if header.title.is_some() {
                meta.title = header.title.clone();
            }
            if header.track_record.is_some() {
                meta.track_record = header.track_record.clone();
            }
            if header.summary.is_some() {
                meta.summary = header.summary.clone();
            }
            if header.golden_finger.is_some() {
                meta.golden_finger = header.golden_finger.clone();
            }
        }
    }
    let name = meta.title.clone().unwrap_or_else(|| files.name.clone());
    let cover_dir = cover_dir_for(root, &files);
    let cover = crate::cover::find_cover(&cover_dir);
    BookEntry {
        name,
        layout: files.layout,
        primary_md: files.primary_md,
        md_count: files.mds.len() as u32,
        chapter_count: chapters,
        word_count: words,
        meta,
        tropes,
        cover,
        cover_dir,
    }
}

/// 主文件同名 .yaml 的书级元数据＋桥段；书库列表对损坏 yaml 降级为缺省
/// （不因一本书的坏文件拖垮整个扫描），编辑器打开该书时会显式告警。
fn meta_and_tropes(primary_md: &Path) -> (BookMeta, Vec<TropeSpan>) {
    match read_yaml_mapping(&sibling_yaml_path(primary_md)) {
        Ok(map) => (
            meta_from_mapping(&map),
            tropes_from_mapping(&map).unwrap_or_default(),
        ),
        Err(_) => (BookMeta::default(), Vec::new()),
    }
}

/// 词表聚合用：主文件同名 yaml 的桥段列表，损坏降级为空（提示尽力而为）。
pub(crate) fn tropes_lossy(primary_md: &Path) -> Vec<TropeSpan> {
    meta_and_tropes(primary_md).1
}

fn md_stats(md: &Path) -> MdStats {
    let Ok(bytes) = fs::read(md) else {
        return MdStats {
            chapters: 0,
            words: 0,
        };
    };
    let raw = String::from_utf8_lossy(&bytes);
    let content = raw.strip_prefix('\u{feff}').unwrap_or(&raw);

    MdStats {
        chapters: content.lines().filter(|l| is_chapter_heading(l)).count() as u32,
        // 与项目/书写章节同一口径（去 frontmatter、去空白、含标点）。
        words: crate::book_file::billed_word_count(content),
    }
}

/// 行首「第X章」中的 X 部分（容忍标题符号与空白前缀），非章标题行返回 None。
pub(crate) fn chapter_digits(line: &str) -> Option<&str> {
    let t = line.trim_start_matches(['#', ' ', '\t']);
    let rest = t.strip_prefix('第')?;
    let end = rest.find('章')?;
    Some(&rest[..end])
}

/// 行首匹配默认章前缀「第X章」。仅用于统计与续号；结构化拆章
/// 由编辑器的显式开章动作负责（设计共识 §四），不追求此处的精确。
pub(crate) fn is_chapter_heading(line: &str) -> bool {
    let Some(digits) = chapter_digits(line) else {
        return false;
    };
    (1..=8).contains(&digits.chars().count())
        && digits.chars().all(|c| {
            matches!(
                c,
                '0'..='9' | '０'..='９' | '〇' | '零' | '一' | '二' | '三' | '四' | '五' | '六'
                    | '七' | '八' | '九' | '两' | '十' | '百' | '千' | '万'
            )
        })
}

fn file_stem_of(path: &Path) -> String {
    path.file_stem()
        .map(|s| s.to_string_lossy().into_owned())
        .unwrap_or_default()
}

/// 新建库的空文件夹判定（工单 #21，spec 书库新建与展示 §三）：目录存在
/// 且没有任何条目（含隐藏文件）。非空时由前端向人确认后再设为当前库——
/// 不自动清洗、不改写任何既有文件（ADR 0002）。
pub fn is_empty_library_dir(path: &Path) -> Result<bool, String> {
    if !path.is_dir() {
        return Err(format!("不是有效的文件夹：{}", path.display()));
    }
    Ok(fs::read_dir(path)
        .map_err(|e| format!("无法读取文件夹 {}：{e}", path.display()))?
        .next()
        .is_none())
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs;
    use tempfile::TempDir;

    fn write(path: &Path, content: &str) {
        if let Some(parent) = path.parent() {
            fs::create_dir_all(parent).unwrap();
        }
        fs::write(path, content).unwrap();
    }

    #[test]
    fn 散文件布局_根目录_md_即书_携带_yaml_侧数据() {
        let root = TempDir::new().unwrap().path().to_path_buf();
        write(&root.join("书甲.md"), "# 第1章\n正文\n## 第2章\n正文");
        write(
            &root.join("书甲.yaml"),
            "书名: 书甲\n成绩: 均订2万\n桥段:\n- 起: 1\n  止: 2\n  类型: [掉马甲]\n",
        );
        write(&root.join("书乙.md"), "第一章\n第二章\n第三章");

        let books = scan_library(&root).unwrap();
        assert_eq!(books.len(), 2);

        let 甲 = books.iter().find(|b| b.name == "书甲").unwrap();
        assert_eq!(甲.layout, Layout::Scattered);
        assert_eq!(甲.chapter_count, 2);
        assert_eq!(甲.md_count, 1);
        assert_eq!(甲.meta.title.as_deref(), Some("书甲"));
        assert_eq!(甲.meta.track_record.as_deref(), Some("均订2万"));
        assert_eq!(甲.tropes.len(), 1);
        assert_eq!(甲.tropes[0].types, vec!["掉马甲".to_string()]);

        let 乙 = books.iter().find(|b| b.name == "书乙").unwrap();
        assert_eq!(乙.chapter_count, 3);
        assert_eq!(乙.meta, BookMeta::default());
        assert!(乙.tropes.is_empty());
    }

    #[test]
    fn 一书一文件夹_识别_主文件取_拆书_md_读其_yaml() {
        let root = TempDir::new().unwrap().path().to_path_buf();
        write(
            &root.join("《书丙》/拆书.md"),
            "第1章\n甲乙丙\n第2章\n丙乙甲",
        );
        write(
            &root.join("《书丙》/拆书.yaml"),
            "书名: 书丙\n金手指: 签到\n",
        );
        write(&root.join("《书丙》/附件/截图.png"), "png");

        let books = scan_library(&root).unwrap();
        assert_eq!(books.len(), 1);
        let book = &books[0];
        // 主名＝书名 > 文件夹名（yaml 残键过渡，工单 #30）。
        assert_eq!(book.name, "书丙");
        assert_eq!(book.layout, Layout::FolderBook);
        assert!(book.primary_md.ends_with("拆书.md"));
        assert_eq!(book.meta.title.as_deref(), Some("书丙"));
        assert_eq!(book.meta.golden_finger.as_deref(), Some("签到"));
        assert_eq!(book.chapter_count, 2);
        assert_eq!(book.word_count, 12); // 附件 png 不计入
    }

    #[test]
    fn 损坏_yaml_该书降级为缺省_不拖垮扫描() {
        let root = TempDir::new().unwrap().path().to_path_buf();
        write(&root.join("坏书.md"), "第1章");
        write(&root.join("坏书.yaml"), "{{{{不是 yaml");
        write(&root.join("好书.md"), "第1章");

        let books = scan_library(&root).unwrap();
        assert_eq!(books.len(), 2);
        let 坏 = books.iter().find(|b| b.name == "坏书").unwrap();
        assert_eq!(坏.meta, BookMeta::default());
        assert!(坏.tropes.is_empty());
    }

    #[test]
    fn 混合布局_两种并存() {
        let root = TempDir::new().unwrap().path().to_path_buf();
        write(&root.join("散书.md"), "第1章");
        write(&root.join("《夹书》/拆书.md"), "第1章");

        let books = scan_library(&root).unwrap();
        assert_eq!(books.len(), 2);
        assert_eq!(
            books
                .iter()
                .filter(|b| b.layout == Layout::Scattered)
                .count(),
            1
        );
        assert_eq!(
            books
                .iter()
                .filter(|b| b.layout == Layout::FolderBook)
                .count(),
            1
        );
    }

    #[test]
    fn 灵感库目录_不算书() {
        let root = TempDir::new().unwrap().path().to_path_buf();
        write(&root.join("书甲.md"), "第1章");
        write(
            &root.join("灵感库/故事卡/外卖成神.md"),
            "---\n标签: [故事]\n---\n\n正文",
        );
        write(&root.join("灵感库/未分类/随手记.md"), "一条点子");

        let books = scan_library(&root).unwrap();
        assert_eq!(books.len(), 1);
        assert_eq!(books[0].name, "书甲");
    }

    #[test]
    fn 项目目录_不算书() {
        let root = TempDir::new().unwrap().path().to_path_buf();
        write(&root.join("书甲.md"), "第1章");
        write(&root.join("项目/《我的书》/项目.yaml"), "书名: 我的书\n");
        write(
            &root.join("项目/《我的书》/正文/0001 初入江湖.md"),
            "第1章 初入江湖",
        );
        // 项目/ 根下的散 .md 也不该被当成一本叫「项目」的书。
        write(&root.join("项目/随手记.md"), "不属于拆书");

        let books = scan_library(&root).unwrap();
        assert_eq!(books.len(), 1);
        assert_eq!(books[0].name, "书甲");
    }

    #[test]
    fn 无_md_的文件夹_不算书() {
        let root = TempDir::new().unwrap().path().to_path_buf();
        write(&root.join("附件/图.png"), "png");
        write(&root.join("素材/note.txt"), "杂项");

        assert!(scan_library(&root).unwrap().is_empty());
    }

    #[test]
    fn 隐藏目录与文件_跳过() {
        let root = TempDir::new().unwrap().path().to_path_buf();
        write(&root.join(".obsidian/app.json"), "{}");
        write(&root.join(".草稿.md"), "第1章");

        assert!(scan_library(&root).unwrap().is_empty());
    }

    #[test]
    fn 文件夹内多个_md_合并统计() {
        let root = TempDir::new().unwrap().path().to_path_buf();
        write(&root.join("书丁/前情.md"), "第一章\n一二三");
        write(&root.join("书丁/拆书.md"), "第二章\n四五六");

        let books = scan_library(&root).unwrap();
        assert_eq!(books.len(), 1);
        let book = &books[0];
        assert_eq!(book.name, "书丁");
        assert_eq!(book.md_count, 2);
        assert_eq!(book.chapter_count, 2);
        assert_eq!(book.word_count, 12);
        assert!(book.primary_md.ends_with("拆书.md"));
    }

    #[test]
    fn 大写扩展名_MD_也识别() {
        let root = TempDir::new().unwrap().path().to_path_buf();
        write(&root.join("旧书.MD"), "第1章");

        let books = scan_library(&root).unwrap();
        assert_eq!(books.len(), 1);
        assert_eq!(books[0].name, "旧书");
    }

    #[test]
    fn 空目录_返回空() {
        let root = TempDir::new().unwrap();
        assert!(scan_library(root.path()).unwrap().is_empty());
    }

    #[test]
    fn 根目录不存在_报错而非空列表() {
        let missing = TempDir::new().unwrap().path().join("不存在的子目录");
        assert!(scan_library(&missing).is_err());
    }

    #[test]
    fn 章前缀判定() {
        assert!(is_chapter_heading("第1章 开端"));
        assert!(is_chapter_heading("## 第12章：翻脸"));
        assert!(is_chapter_heading("第一百零一章"));
        assert!(is_chapter_heading("第２０章")); // 全角数字
        assert!(!is_chapter_heading("第一次相遇"));
        assert!(!is_chapter_heading("第三种颜色"));
        assert!(!is_chapter_heading("第 abc 章"));
        assert!(!is_chapter_heading("正文提到第三章不算"));
    }

    #[test]
    fn bom_不遮挡首行章前缀() {
        let root = TempDir::new().unwrap().path().to_path_buf();
        write(&root.join("记事本.md"), "\u{feff}第一章\n正文");

        let books = scan_library(&root).unwrap();
        assert_eq!(books[0].chapter_count, 1);
    }

    // --- 新建书（spec 书库新建与展示 §二）---

    #[test]
    fn 新建书_一书一文件夹_模板初始稿_懒生成() {
        let tmp = TempDir::new().unwrap();
        let root = tmp.path().to_path_buf();

        let book = create_book(&root, "我的新书").unwrap();

        // 主名＝书档书名（模板里 `书名：{书名}` 已替换）> 文件夹名。
        assert_eq!(book.name, "我的新书");
        assert_eq!(book.layout, Layout::FolderBook);
        assert!(book.primary_md.ends_with("拆书.md"));
        // 落点：只建《书名》/＋初始 拆书.md（模板套用，首次新建顺带落默认
        // 模板——懒生成）；yaml 与附件/懒生成，不预建。
        assert_eq!(
            fs::read_to_string(&book.primary_md).unwrap(),
            DEFAULT_TEMPLATE.replace("{书名}", "我的新书")
        );
        assert_eq!(
            fs::read_to_string(&root.join(TEMPLATE_FILE)).unwrap(),
            DEFAULT_TEMPLATE
        );
        assert!(!root.join("《我的新书》/拆书.yaml").exists());
        assert!(!root.join("《我的新书》/附件").exists());

        // 扫描立刻能认出这本书；库根模板不算书。
        let books = scan_library(&root).unwrap();
        assert_eq!(books.len(), 1);
        assert_eq!(books[0].name, "我的新书");
        assert_eq!(books[0].meta.track_record, None, "模板空成绩列显示空");
    }

    #[test]
    fn 新建书_同名报错_不自动续号() {
        let tmp = TempDir::new().unwrap();
        let root = tmp.path().to_path_buf();
        create_book(&root, "书甲").unwrap();

        let err = create_book(&root, "书甲").unwrap_err();
        assert!(err.contains("书甲"), "报错应指名书名：{err}");
        // 不续号：库里只有一本。
        assert_eq!(scan_library(&root).unwrap().len(), 1);
    }

    #[test]
    fn 新建书_书名清洗_去书名号与空白_非法字符替换() {
        let tmp = TempDir::new().unwrap();
        let root = tmp.path().to_path_buf();

        let book = create_book(&root, " 《剑/来：外传》 ").unwrap();
        // 主名＝书档书名（模板占位符替换后的净书名）；文件夹仍是书名号形态。
        assert_eq!(book.name, "剑_来：外传");
        assert!(root.join("《剑_来：外传》/拆书.md").is_file());

        // 只剩符号/空串报错，不建目录。
        assert!(create_book(&root, "《  》").is_err());
        assert!(create_book(&root, "《??》").is_err());
        let entries = fs::read_dir(&root).unwrap().count();
        // 成功那次新建留下的：《剑_来：外传》/＋懒生成的 拆书模板.md。
        assert_eq!(entries, 2, "失败的建不应再留下目录");
    }

    // --- 拆书模板（工单 #29，spec 拆书保存与模板 §三）---

    #[test]
    fn 拆书模板_首次打开_落默认模板_已有_不覆盖() {
        let tmp = TempDir::new().unwrap();
        let root = tmp.path().to_path_buf();

        let entry = open_book_template(&root).unwrap();
        assert_eq!(entry.name, "拆书模板");
        assert_eq!(entry.primary_md, root.join(TEMPLATE_FILE));
        assert_eq!(
            fs::read_to_string(&root.join(TEMPLATE_FILE)).unwrap(),
            DEFAULT_TEMPLATE
        );

        // 用户改过的模板原样保留，不被默认值覆盖。
        write(
            &root.join(TEMPLATE_FILE),
            "> [!书档]\n> 书名：{书名}\n\n第一章\n",
        );
        assert_eq!(
            open_book_template(&root).unwrap().primary_md,
            root.join(TEMPLATE_FILE)
        );
        assert_eq!(
            fs::read_to_string(&root.join(TEMPLATE_FILE)).unwrap(),
            "> [!书档]\n> 书名：{书名}\n\n第一章\n"
        );
    }

    #[test]
    fn 新建书_套用自编模板_书名替换_含多次出现_其余占位符原样() {
        let tmp = TempDir::new().unwrap();
        let root = tmp.path().to_path_buf();
        write(
            &root.join(TEMPLATE_FILE),
            "> [!书档]\n> 书名：{书名}（{书名}）\n> 备注：{日期}\n\n第1章 {书名}\n",
        );

        let book = create_book(&root, "我的新书").unwrap();

        assert_eq!(
            fs::read_to_string(&book.primary_md).unwrap(),
            "> [!书档]\n> 书名：我的新书（我的新书）\n> 备注：{日期}\n\n第1章 我的新书\n"
        );
        // 模板本体不动：占位符仍在，下一本书继续套。
        assert_eq!(
            fs::read_to_string(&root.join(TEMPLATE_FILE)).unwrap(),
            "> [!书档]\n> 书名：{书名}（{书名}）\n> 备注：{日期}\n\n第1章 {书名}\n"
        );
    }

    #[test]
    fn 新建书_模板读写失败_回退空稿_不阻断() {
        let tmp = TempDir::new().unwrap();
        let root = tmp.path().to_path_buf();
        // 占住模板路径的目录：默认模板写不进、也读不了——回退空稿。
        fs::create_dir_all(&root.join(TEMPLATE_FILE)).unwrap();

        let book = create_book(&root, "我的新书").unwrap();
        assert_eq!(fs::read_to_string(&book.primary_md).unwrap(), "");

        // 模板入口把失败亮出来（编辑入口需要真实的文件）。
        assert!(open_book_template(&root).is_err());
    }

    #[test]
    fn 扫描与搜索_库根拆书模板_不算书() {
        let root = TempDir::new().unwrap().path().to_path_buf();
        write(&root.join("书甲.md"), "第1章");
        write(
            &root.join(TEMPLATE_FILE),
            "> [!书档]\n> 书名：{书名}\n\n第1章\n",
        );

        let books = scan_library(&root).unwrap();
        assert_eq!(books.len(), 1);
        assert_eq!(books[0].name, "书甲");

        // 全文搜索与扫描共用同一套书文件收集（vocabulary 亦然），模板里的
        // 词不该命中模板这份「书」。
        let hits = crate::search::search_library(&root, "{书名}").unwrap();
        assert!(hits.is_empty(), "模板不是书，不该被搜到：{hits:?}");
    }

    // --- 封面扫描（工单 #23，spec 书库新建与展示 §五）---

    #[test]
    fn 封面_一书一文件夹_落书内附件() {
        let root = TempDir::new().unwrap().path().to_path_buf();
        write(&root.join("《书丙》/拆书.md"), "第1章");
        write(&root.join("《书丙》/附件/封面.png"), "png");

        let books = scan_library(&root).unwrap();
        assert_eq!(books[0].cover, Some(root.join("《书丙》/附件/封面.png")));
        assert_eq!(books[0].cover_dir, root.join("《书丙》/附件"));
    }

    #[test]
    fn 封面_散文件书_落库根附件_按书名分目录() {
        let root = TempDir::new().unwrap().path().to_path_buf();
        write(&root.join("书乙.md"), "第1章");
        write(&root.join("附件/书乙/封面.jpg"), "jpg");

        let books = scan_library(&root).unwrap();
        assert_eq!(books[0].cover, Some(root.join("附件/书乙/封面.jpg")));
        assert_eq!(books[0].cover_dir, root.join("附件/书乙"));
    }

    #[test]
    fn 封面_无封面为空_删文件即撤() {
        let root = TempDir::new().unwrap().path().to_path_buf();
        write(&root.join("书甲.md"), "第1章");
        write(&root.join("附件/书甲/封面.png"), "png");

        let books = scan_library(&root).unwrap();
        assert!(books[0].cover.is_some());
        fs::remove_file(root.join("附件/书甲/封面.png")).unwrap();
        assert!(scan_library(&root).unwrap()[0].cover.is_none());
    }

    #[test]
    fn 封面_多扩展名并存_按_png_优先() {
        let root = TempDir::new().unwrap().path().to_path_buf();
        write(&root.join("《书》/拆书.md"), "第1章");
        write(&root.join("《书》/附件/封面.webp"), "w");
        write(&root.join("《书》/附件/封面.jpg"), "j");
        write(&root.join("《书》/附件/封面.png"), "p");

        assert_eq!(
            scan_library(&root).unwrap()[0].cover,
            Some(root.join("《书》/附件/封面.png"))
        );
    }

    #[test]
    fn 封面_端到端_新建库_新建书_设封面_扫描识别() {
        let tmp = TempDir::new().unwrap();
        let root = tmp.path().to_path_buf();

        let book = create_book(&root, "我的新书").unwrap();
        assert!(book.cover.is_none(), "新书无封面");

        // 模拟用户选图：库外一张 png。
        let picked = tmp.path().join("选图.png");
        fs::write(&picked, b"png bytes").unwrap();
        let dest = crate::cover::set_cover(&book.cover_dir, &picked).unwrap();
        assert_eq!(dest, root.join("《我的新书》/附件/封面.png"));

        let books = scan_library(&root).unwrap();
        assert_eq!(books[0].cover.as_deref(), Some(dest.as_path()));
        assert_eq!(
            fs::read(&dest).unwrap(),
            "png bytes".as_bytes(),
            "拷贝而非引用"
        );
    }

    #[test]
    fn 新建库_空文件夹判定_隐藏项也算非空() {
        let tmp = TempDir::new().unwrap();
        let empty = tmp.path().join("空库");
        fs::create_dir_all(&empty).unwrap();
        assert!(is_empty_library_dir(&empty).unwrap());

        let occupied = tmp.path().join("非空");
        fs::create_dir_all(occupied.join(".obsidian")).unwrap();
        assert!(!is_empty_library_dir(&occupied).unwrap());

        assert!(is_empty_library_dir(&tmp.path().join("不存在")).is_err());
    }

    // --- 列表取数（工单 #30，spec 拆书保存与模板 §五「列表列过渡」）---

    #[test]
    fn 列表取数_md书档优先_yaml残键过渡_两者皆无为空() {
        let root = TempDir::new().unwrap().path().to_path_buf();
        // 甲：md 书档与 yaml 残键都有——md 优先。
        write(
            &root.join("书甲.md"),
            "> [!书档]\n> 书名：纸面名\n> 成绩：纸面成绩\n> 金手指：纸面金手指\n\n第1章",
        );
        write(
            &root.join("书甲.yaml"),
            "书名: yaml名\n成绩: yaml成绩\n金手指: yaml金手指\n",
        );
        // 乙：只有 yaml 残键（还没打开过的旧书）。
        write(&root.join("书乙.md"), "第1章");
        write(&root.join("书乙.yaml"), "成绩: 均订两万\n");
        // 丙：两处皆无。
        write(&root.join("书丙.md"), "第1章");

        let books = scan_library(&root).unwrap();
        let 甲 = books
            .iter()
            .find(|b| b.primary_md.ends_with("书甲.md"))
            .unwrap();
        assert_eq!(甲.name, "纸面名");
        assert_eq!(甲.meta.track_record.as_deref(), Some("纸面成绩"));
        assert_eq!(甲.meta.golden_finger.as_deref(), Some("纸面金手指"));
        let 乙 = books
            .iter()
            .find(|b| b.primary_md.ends_with("书乙.md"))
            .unwrap();
        assert_eq!(乙.name, "书乙", "无书档无yaml书名→文件夹名兜底");
        assert_eq!(乙.meta.track_record.as_deref(), Some("均订两万"));
        let 丙 = books
            .iter()
            .find(|b| b.primary_md.ends_with("书丙.md"))
            .unwrap();
        assert_eq!(丙.name, "书丙");
        assert_eq!(丙.meta, BookMeta::default());
    }

    #[test]
    fn 列表取数_迁移后与纸面一致_扫描不写盘() {
        let root = TempDir::new().unwrap().path().to_path_buf();
        let md = root.join("《旧书》/拆书.md");
        write(&md, "第1章\n正文");
        write(
            &root.join("《旧书》/拆书.yaml"),
            "书名: 旧书\n成绩: 均订三万\n桥段:\n- 起: 1\n  止: 2\n  类型: [掉马甲]\n",
        );

        // 扫描只读：迁移前后 yaml/md 都不动。
        let before = (
            fs::read(&md).unwrap(),
            fs::read(&root.join("《旧书》/拆书.yaml")).unwrap(),
        );
        let books = scan_library(&root).unwrap();
        assert_eq!(books[0].name, "旧书", "yaml 残键过渡显示");
        assert_eq!(
            (
                fs::read(&md).unwrap(),
                fs::read(&root.join("《旧书》/拆书.yaml")).unwrap()
            ),
            before,
            "书库扫描绝不写盘"
        );

        // 打开书迁移一次后，列表成绩列与纸面一致。
        crate::book_file::migrate_book_header(&md).unwrap();
        let books = scan_library(&root).unwrap();
        assert_eq!(books[0].name, "旧书");
        assert_eq!(books[0].meta.track_record.as_deref(), Some("均订三万"));
        assert_eq!(books[0].tropes.len(), 1, "桥段标注无损");
    }
}
